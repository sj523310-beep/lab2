#include <stdio.h>

int main(void) {
    double a, b, c;

    printf("Enter three real numbers: ");
    if (scanf("%lf %lf %lf", &a, &b, &c) != 3) {
        printf("Input error.\n");
        return 1;
    }

    if (a == b || a == c || b == c)
        printf("There is at least one equal pair.\n");
    else
        printf("There are no equal pairs.\n");

    return 0;
}
