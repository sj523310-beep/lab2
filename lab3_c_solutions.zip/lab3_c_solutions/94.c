#include <stdio.h>

int main(void) {
    int n;
    int d1, d2, d3, d4, d5, d6;

    printf("Enter a six-digit number: ");
    if (scanf("%d", &n) != 1) {
        printf("Input error.\n");
        return 1;
    }

    if (n < 100000 || n > 999999) {
        printf("The number must have six digits.\n");
        return 1;
    }

    d1 = n / 100000;
    d2 = (n / 10000) % 10;
    d3 = (n / 1000) % 10;
    d4 = (n / 100) % 10;
    d5 = (n / 10) % 10;
    d6 = n % 10;

    if (d1 + d2 + d3 == d4 + d5 + d6)
        printf("The number is lucky.\n");
    else
        printf("The number is not lucky.\n");

    return 0;
}
