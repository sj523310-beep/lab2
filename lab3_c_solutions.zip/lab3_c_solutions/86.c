#include <stdio.h>

int main(void) {
    double h1, h2, h3;

    printf("Enter the heights of three people: ");
    if (scanf("%lf %lf %lf", &h1, &h2, &h3) != 3) {
        printf("Input error.\n");
        return 1;
    }

    if (h1 == h2 && h2 == h3)
        printf("All three people have the same height.\n");
    else
        printf("The heights are not all equal.\n");

    return 0;
}
