#include <stdio.h>

int main(void) {
    int m, n;

    printf("Enter two integers m and n: ");
    if (scanf("%d %d", &m, &n) != 2) {
        printf("Input error.\n");
        return 1;
    }

    if (m == n) {
        m = 0;
        n = 0;
    } else if (m > n) {
        n = m;
    } else {
        m = n;
    }

    printf("m = %d, n = %d\n", m, n);
    return 0;
}
