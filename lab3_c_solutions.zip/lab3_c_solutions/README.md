# Lab 3 — Branching algorithms (C)

This repository contains separate C programs for tasks 83, 90, 109, 33, 94, 72, 86, 29, 20 and 65 from the provided assignment.

## Files
- `83.c` — check whether any pair among three real numbers is equal.
- `90.c` — check whether a brick can pass through a rectangular opening.
- `109.c` — identify the largest, smallest and middle of three different integers.
- `33.c` — check which of `a`, `b`, `c` are divisible by `k`.
- `94.c` — check whether a six-digit number is lucky.
- `72.c` — check whether the sum is greater than 32767.
- `86.c` — check whether three heights are equal.
- `29.c` — replace two integers according to task 29.
- `20.c` — check whether all digits of a three-digit number are equal and whether any digits match.
- `65.c` — sort `sin(x)`, `cos(x)` and, when defined, `tan(x)` in ascending order. Here `x` is entered in radians.

## Compile
Use GCC. For task 65, link the math library:

```bash
gcc 83.c -o task83
gcc 90.c -o task90
gcc 109.c -o task109
gcc 33.c -o task33
gcc 94.c -o task94
gcc 72.c -o task72
gcc 86.c -o task86
gcc 29.c -o task29
gcc 20.c -o task20
gcc 65.c -o task65 -lm
```

Run the compiled program from your terminal, for example `./task83` (on Windows with MinGW, use `task83.exe`).
