#include <stdio.h>
#include <math.h>

int main(void) {
    double x, values[3];
    const char *names[3] = {"sin(x)", "cos(x)", "tan(x)"};
    int count = 0, i, j;
    double temp;
    const char *temp_name;

    printf("Enter x in radians: ");
    if (scanf("%lf", &x) != 1) {
        printf("Input error.\n");
        return 1;
    }

    values[count] = sin(x);
    names[count++] = "sin(x)";

    values[count] = cos(x);
    names[count++] = "cos(x)";

    if (fabs(cos(x)) < 1e-12) {
        printf("tan(x) is undefined for this value of x and will be skipped.\n");
    } else {
        values[count] = tan(x);
        names[count++] = "tan(x)";
    }

    for (i = 0; i < count - 1; i++) {
        for (j = 0; j < count - 1 - i; j++) {
            if (values[j] > values[j + 1]) {
                temp = values[j];
                values[j] = values[j + 1];
                values[j + 1] = temp;

                temp_name = names[j];
                names[j] = names[j + 1];
                names[j + 1] = temp_name;
            }
        }
    }

    printf("Values in ascending order:\n");
    for (i = 0; i < count; i++)
        printf("%s = %.6f\n", names[i], values[i]);

    return 0;
}
