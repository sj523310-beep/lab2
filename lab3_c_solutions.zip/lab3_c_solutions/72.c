#include <stdio.h>

int main(void) {
    int a, b;
    long long sum;

    printf("Enter two signed integers: ");
    if (scanf("%d %d", &a, &b) != 2) {
        printf("Input error.\n");
        return 1;
    }

    sum = (long long)a + b;

    if (sum > 32767)
        printf("Overflow: the sum is greater than 32767.\n");
    else
        printf("Sum = %lld\n", sum);

    return 0;
}
