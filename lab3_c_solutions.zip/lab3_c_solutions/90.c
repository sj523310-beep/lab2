#include <stdio.h>

int main(void) {
    double a, b, c, x, y;
    int fits;

    printf("Enter brick edges a, b, c and opening sides x, y: ");
    if (scanf("%lf %lf %lf %lf %lf", &a, &b, &c, &x, &y) != 5) {
        printf("Input error.\n");
        return 1;
    }

    fits = (a <= x && b <= y) || (a <= y && b <= x) ||
           (a <= x && c <= y) || (a <= y && c <= x) ||
           (b <= x && c <= y) || (b <= y && c <= x);

    if (fits)
        printf("The brick can pass through the opening.\n");
    else
        printf("The brick cannot pass through the opening.\n");

    return 0;
}
