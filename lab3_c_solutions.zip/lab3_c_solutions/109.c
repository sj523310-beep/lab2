#include <stdio.h>

int main(void) {
    int a, b, c;
    int largest, smallest, middle;

    printf("Enter three different integers: ");
    if (scanf("%d %d %d", &a, &b, &c) != 3) {
        printf("Input error.\n");
        return 1;
    }

    if (a == b || a == c || b == c) {
        printf("The numbers must be different.\n");
        return 1;
    }

    largest = a;
    if (b > largest) largest = b;
    if (c > largest) largest = c;

    smallest = a;
    if (b < smallest) smallest = b;
    if (c < smallest) smallest = c;

    middle = a + b + c - largest - smallest;

    if (largest == a) printf("Largest: first number\n");
    else if (largest == b) printf("Largest: second number\n");
    else printf("Largest: third number\n");

    if (smallest == a) printf("Smallest: first number\n");
    else if (smallest == b) printf("Smallest: second number\n");
    else printf("Smallest: third number\n");

    if (middle == a) printf("Middle: first number\n");
    else if (middle == b) printf("Middle: second number\n");
    else printf("Middle: third number\n");

    return 0;
}
