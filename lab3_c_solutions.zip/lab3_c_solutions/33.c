#include <stdio.h>

int main(void) {
    int a, b, c, k;
    int found = 0;

    printf("Enter a, b, c and k: ");
    if (scanf("%d %d %d %d", &a, &b, &c, &k) != 4) {
        printf("Input error.\n");
        return 1;
    }

    if (k == 0) {
        printf("Zero cannot be a divisor.\n");
        return 0;
    }

    if (a % k == 0) {
        printf("k is a divisor of a.\n");
        found = 1;
    }
    if (b % k == 0) {
        printf("k is a divisor of b.\n");
        found = 1;
    }
    if (c % k == 0) {
        printf("k is a divisor of c.\n");
        found = 1;
    }

    if (!found)
        printf("k is not a divisor of a, b or c.\n");

    return 0;
}
