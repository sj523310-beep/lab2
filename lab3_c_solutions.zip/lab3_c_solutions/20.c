#include <stdio.h>

int main(void) {
    int n, a, b, c;

    printf("Enter a three-digit integer: ");
    if (scanf("%d", &n) != 1) {
        printf("Input error.\n");
        return 1;
    }

    if (n < 100 || n > 999) {
        printf("The number must be three-digit and positive.\n");
        return 1;
    }

    a = n / 100;
    b = (n / 10) % 10;
    c = n % 10;

    if (a == b && b == c)
        printf("All digits are equal.\n");
    else
        printf("Not all digits are equal.\n");

    if (a == b || a == c || b == c)
        printf("At least two digits are equal.\n");
    else
        printf("All digits are different.\n");

    return 0;
}
